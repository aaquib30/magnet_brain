<?php 
    $session = session();

    // Check if the user is not logged in
    if (!$session->get('logged_in')) {
        // Redirect to the login page
        header("Location: " . base_url('login'));
    exit();
    }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit User</title>
    <link rel="stylesheet" href="<?= base_url('css/indexcss.css') ?>">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background-color: #f4f4f9;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            flex: 1;
            background-color: #333;
            color: #fff;
            padding: 20px;
        }

        .sidebar h2 {
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar li a {
            display: block;
            padding: 10px;
            color: #fff;
            text-decoration: none;
            border-bottom: 1px solid #555;
        }

        .sidebar li a:hover {
            background-color: #444;
        }

        .main-content {
            flex: 3;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: calc(100vw - 300px); /* Adjust the width as per your sidebar's width */
            max-width: 800px; /* Set a maximum width if needed */
            margin: 20px; /* Add some margin for spacing */
            box-sizing: border-box;
            margin-left: 500px;
    
    width: calc(100% - 250px);


        }

        .user-form label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
            color: #333;
        }

        .user-form input[type="text"],
        .user-form input[type="email"],
        .user-form select {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 18px;
            box-sizing: border-box;
        }

        .user-form button {
            padding: 12px 20px;
            font-size: 20px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            outline: none;
            color: #fff;
            background-color: #4CAF50;
            border: none;
            border-radius: 8px;
            display: block;
            width: 100%;
            margin-top: 20px;
        }

        .user-form button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="user-info">
            <span>Welcome, <?= session()->get('username') ?></span>
            <a href="<?= site_url('auth/logout') ?>" class="logout-btn">Logout</a>
        </div>
    </div>
    <div class="sidebar">
        <h2>Menu</h2>
        <ul>
            <li><a href="<?= site_url('task/createlist') ?>">Create Task</a></li>
            <li><a href="<?= site_url('task/taskList') ?>">Task List</a></li>
            <li><a href="<?= site_url('user/list') ?>">User</a></li>
        </ul>
    </div>
    <div class="main-content">
        <h2>Edit User</h2>
        <form action="<?= site_url('user/editUser/' . $user['id']) ?>" method="post" class="user-form">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" value="<?= $user['username'] ?>" required><br>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?= $user['email'] ?>" required><br>
            <label for="role">Role:</label>
            <select id="role" name="role" required>
                <option value="admin" <?= ($user['role'] == 'admin') ? 'selected' : '' ?>>Admin</option>
                <option value="user" <?= ($user['role'] == 'user') ? 'selected' : '' ?>>User</option>
            </select><br>
            <button type="submit">Update User</button>
        </form>
    </div>
</body>
</html>
