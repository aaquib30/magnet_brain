<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assigned Tasks</title>
    <!-- Add your CSS stylesheets here -->
</head>
<body>
    <h2>Assigned Tasks</h2>
    <div>
        <table border="1">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Due Date</th>
                    <th>Priority</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tasks as $task): ?>
                <tr>
                    <td><?= esc($task['title']) ?></td>
                    <td><?= esc($task['description']) ?></td>
                    <td><?= esc($task['due_date']) ?></td>
                    <td style="color: <?= ($task['priority'] == 'high') ? 'red' : (($task['priority'] == 'medium') ? 'orange' : 'green') ?>">
                        <?= esc($task['priority']) ?>
                    </td>
                    <td><?= esc($task['status']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
