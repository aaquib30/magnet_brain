<?php
$session = session();
$role = $session->get('role');
if (!isset($role) || $role !== 'admin') {
    header("Location: " . base_url('home'));
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="<?= base_url('css/indexcss.css') ?>">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background-color: #f4f4f9;
        }

        .header {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .user-info {
            display: flex;
            align-items: center;
        }

        .user-info span {
            margin-right: 15px;
        }

        .logout-btn {
            background-color: #ff4b5c;
            color: #fff;
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 5px;
        }

        .logout-btn:hover {
            background-color: #ff0000;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 250px;
            background-color: #333;
            color: #fff;
            padding-top: 20px;
            position: fixed;
            height: 100vh;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            padding: 10px;
            text-align: center;
        }

        .sidebar ul li a {
            display: block;
            padding: 10px;
            color: #fff;
            text-decoration: none;
            border-bottom: 1px solid #555;
        }

        .sidebar ul li a:hover {
            background-color: #444;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
            width: calc(100% - 250px);
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .user-form label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
            color: #333;
        }

        .user-form input[type="text"],
        .user-form input[type="email"],
        .user-form input[type="password"],
        .user-form select {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 18px;
            box-sizing: border-box;
        }

        .user-form button {
            padding: 12px 20px;
            font-size: 20px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            outline: none;
            color: #fff;
            background-color: #4CAF50;
            border: none;
            border-radius: 8px;
            display: block;
            width: 100%;
            margin-top: 20px;
        }

        .user-form button:hover {
            background-color: #45a049;
        }

        h2, h3 {
            color: #333;
        }

        p {
            color: #555;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="user-info">
            <span>Welcome, <?= session()->get('username') ?></span>
            <a href="<?= site_url('auth/logout') ?>" class="logout-btn">Logout</a>
        </div>
    </div>
    <div class="container">
        <div class="sidebar">
            <h2>Menu</h2>
            <ul>
            <li><a href="<?= site_url('task/taskList') ?>">Task List</a></li>
        <?php if (session()->get('role') === 'admin') : ?>
            <li><a href="<?= site_url('task/createlist') ?>">Create Task</a></li>
            <li><a href="<?= site_url('user/list') ?>">User</a></li>
        <?php endif; ?>
            </ul>
        </div>
        <div class="main-content">
            <h2>Register Form</h2>
            <form action="<?= base_url('auth/registerSubmit') ?>" method="post" class="user-form">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>

                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>

                <label for="role">Role:</label>
                <select id="role" name="role" required>
                    <option value="admin">Admin</option>
                    <option value="user">User</option>
                </select>

                <button type="submit">Register</button>
            </form>
        </div>
    </div>
</body>
</html>
