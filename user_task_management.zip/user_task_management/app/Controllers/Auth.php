<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;

class Auth extends Controller
{
    public function register()
    {
        helper(['form']);
        echo view('register');
    }

    public function registerSubmit()
    {
        $model = new UserModel();
        $data = [
            'username' => $this->request->getPost('username'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'email'    => $this->request->getPost('email'),
            'role'     => 'user'
        ];
        $model->save($data);
        return redirect()->to('user/list');
    }

    public function login()
    {
        helper(['form']);
        echo view('login');
    }

    public function loginSubmit()
    {
        $session = session();
        $model = new UserModel();

        $username = $this->request->getVar('username');
        $password = $this->request->getVar('password');
        $data = $model->where('username', $username)->first();

        if ($data) {
            $pass = $data['password'];
            $verify_pass = password_verify($password, $pass);
            if ($verify_pass) {
                $ses_data = [
                    'id'       => $data['id'],
                    'username' => $data['username'],
                    'email'    => $data['email'],
                    'role'     => $data['role'],
                    'logged_in' => TRUE
                ];
                $session->set($ses_data);
                return redirect()->to('/task');
            } else {
                $session->setFlashdata('msg', 'Wrong Password');
                return redirect()->to('/login');
            }
        } else {
            $session->setFlashdata('msg', 'Username not found');
            return redirect()->to('/login');
        }
    }



    
    public function logout()
    {
        $session = session();
        $session->destroy();
        return redirect()->to('/login');
    }




public function userList()
{
    $userModel = new UserModel();
    $data['users'] = $userModel->findAll();

    return view('userlist', $data);
}




public function editUser($id)
{
    $model = new UserModel();
    $data['user'] = $model->find($id);

    return view('edit_user', $data);
}

public function updateUser($id)
{
    $model = new UserModel();
    $data = [
        'username' => $this->request->getPost('username'),
        'email'    => $this->request->getPost('email'),
        'role'    => $this->request->getPost('role'),
    ];
    $model->update($id, $data);

    return redirect()->to('/user/list');
}

public function deleteUser($id)
{
    $model = new UserModel();
    $model->delete($id);

    return redirect()->to('/user/list');
}





}
