<?php

namespace App\Models;

use CodeIgniter\Model;

class TaskModel extends Model
{
    protected $table = 'tasks';
    protected $primaryKey = 'id';
    protected $allowedFields = ['title', 'description', 'due_date', 'priority', 'assigned_to', 'status', 'updated_by', 'created_at', 'updated_at'];

    // Enable automatic handling of created_at and updated_at fields
    protected $useTimestamps = true;
}
?>