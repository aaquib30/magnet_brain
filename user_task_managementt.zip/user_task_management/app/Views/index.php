<?php 
    // $session = session();

    // // Check if the user is not logged in
    // if (!$session->get('logged_in')) {
    //     // Redirect to the login page
    //     header("Location: " . base_url('login'));
    // exit();
    // }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Task Management</title>
    <link rel="stylesheet" type="text/css" href="<?= base_url('css/indexcss.css') ?>">

    <style>
table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
        font-size: 18px;
        text-align: left;
    }
    table th, table td {
        padding: 12px;
        border: 1px solid #ddd;
    }
    table th {
        background-color: #f2f2f2;
    }

</style>
</head>
<body>
    <div class="header">
        <div class="user-info">
            <span>Welcome, <?= session()->get('username') ?></span>
            <a href="<?= site_url('auth/logout') ?>" class="logout-btn">Logout</a>
        </div>
    </div>
    <div class="sidebar">
        <h2>Menu</h2>
        <ul>
        <li><a href="<?= site_url('task/taskList') ?>">Task List</a></li>
        <?php if (session()->get('role') === 'admin') : ?>
            <li><a href="<?= site_url('task/createlist') ?>">Create Task</a></li>
            <li><a href="<?= site_url('user/list') ?>">User</a></li>
        <?php endif; ?>
        </ul>
    </div>
    <div class="main-content">
        <h2>Task Management</h2>
        <?php if (isset($role) && $role === 'admin'): ?>
            <h3>Create New Task</h3>
            <form method="POST" action="<?= site_url('task/create') ?>">
                <label>Title:</label>
                <input type="text" name="title" required><br>
                <label>Description:</label>
                <textarea name="description" required></textarea><br>
                <label>Due Date:</label>
                <input type="date" name="due_date" required><br>
                <label>Priority:</label>
                <select name="priority" required>
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                </select><br>
                <label>Assign To:</label>
                <select name="assigned_to" required>
                    <?php foreach ($users as $user): ?>
                        <option value="<?= $user['id'] ?>"><?= $user['username'].' ['.$user['role'].']' ?></option>
                    <?php endforeach; ?>
                </select><br>
                <button type="submit">Create Task</button>
            </form>
        <?php else: ?>
            <p>Welcome, user. You can view your assigned tasks here.</p>
            <?php  echo view('user_task'); ?>
        <?php endif; ?>
    </div>
</body>
</html>
