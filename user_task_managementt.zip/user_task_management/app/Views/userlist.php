<!-- userlist.php -->

<!DOCTYPE html>
<html>
<head>
    <title>User List</title>
    <link rel="stylesheet" type="text/css" href="<?= base_url('css/indexcss.css') ?>">

<style>
    body {
        font-family: Arial, sans-serif;
    }
    .main-content {
        padding: 20px;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
        font-size: 18px;
        text-align: left;
    }
    table th, table td {
        padding: 12px;
        border: 1px solid #ddd;
    }
    table th {
        background-color: #f2f2f2;
    }
    .btn {
        display: inline-block;
        padding: 10px 15px;
        font-size: 16px;
        cursor: pointer;
        text-align: center;
        text-decoration: none;
        outline: none;
        color: #fff;
        border: none;
        border-radius: 15px;
        box-shadow: 0 9px #999;
    }
    .btn:hover {
        background-color: #3e8e41;
    }
    .btn:active {
        background-color: #3e8e41;
        box-shadow: 0 5px #666;
        transform: translateY(4px);
    }
    .btn-delete {
        background-color: #f44336;
    }
    .btn-delete:hover {
        background-color: #d32f2f;
    }
    .btn-delete:active {
        background-color: #d32f2f;
        box-shadow: 0 5px #666;
        transform: translateY(4px);
    }
    .btn-edit {
        background-color: #008CBA;
    }
    .btn-edit:hover {
        background-color: #007bb5;
    }
    .btn-edit:active {
        background-color: #007bb5;
        box-shadow: 0 5px #666;
        transform: translateY(4px);
    }
    .btn-view {
        background-color: #559215;
    }
    .btn-view:hover {
        background-color: #559220;
    }
    .btn-view:active {
        background-color: #559220;
        box-shadow: 0 5px #666;
        transform: translateY(4px);
    }
    .priority-low {
        background-color: #e2b9b9;
    }
    .priority-medium {
        background-color: #ff7777;
    }
    .priority-high {
        background-color: #ff2929;
    }
    .pagination {
        display: flex;
        justify-content: center;
        margin: 20px 0;
    }
    .pagination a {
        color: black;
        float: left;
        padding: 8px 16px;
        text-decoration: none;
        transition: background-color .3s;
        border: 1px solid #ddd;
        margin: 0 4px;
    }
    .pagination a.active {
        background-color: #4CAF50;
        color: white;
        border: 1px solid #4CAF50;
    }
    .pagination a:hover:not(.active) {
        background-color: #ddd;
    }
</style>
</head>
<body>
    <div class="header">
        <div class="user-info">
            <span>Welcome, <?= session()->get('username') ?></span>
            <a href="<?= site_url('auth/logout') ?>" class="logout-btn">Logout</a>
        </div>
    </div>
    <div class="sidebar">
        <h2>Menu</h2>
        <ul>
        <li><a href="<?= site_url('task/taskList') ?>">Task List</a></li>
        <?php if (session()->get('role') === 'admin') : ?>
            <li><a href="<?= site_url('task/createlist') ?>">Create Task</a></li>
            <li><a href="<?= site_url('user/list') ?>">User</a></li>
        <?php endif; ?>
        </ul>
    </div>
    <div class="main-content">
        <h2>User List</h2>
        <a href="<?= site_url('auth/register') ?>" class="btn btn-add">Add New User</a>
        <table>
            <!-- Table headers -->
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?= $user['username'] ?></td>
                        <td><?= $user['email'] ?></td>
                        <td>
                            <a href="<?= site_url('user/editUser/' . $user['id']) ?>" class="btn btn-edit">Edit</a>
                            <a href="<?= site_url('user/deleteUser/' . $user['id']) ?>" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
