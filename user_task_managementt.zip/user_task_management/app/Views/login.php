<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="<?= base_url('css/styles.css') ?>">
</head>
<body>
<h2>Login Form</h2>
<?php if (session()->getFlashdata('msg')) : ?>
    <div><?= session()->getFlashdata('msg') ?></div>
<?php endif; ?>
<div class="container">
    <form action="<?= base_url('auth/loginSubmit') ?>" method="post">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" required>
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required>
        <button type="submit">Login</button>
    </form>
</div>
</body>
</html>
 