<?php 
    $session = session();

 
    if (!$session->get('logged_in')) {
        header("Location: " . base_url('login'));
    exit();
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Details</title>
    <!-- <link rel="stylesheet" href="<?= base_url('css/styles.css') ?>"> -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .header {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .user-info {
            display: flex;
            align-items: center;
        }

        .user-info span {
            margin-right: 15px;
        }

        .logout-btn {
            background-color: #ff4b5c;
            color: #fff;
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 5px;
        }

        .logout-btn:hover {
            background-color: #ff0000;
        }

        .sidebar {
            width: 250px;
            background-color: #333;
            color: #fff;
            height: 100vh;
            position: fixed;
            padding-top: 20px;
            overflow-y: auto;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            padding: 10px;
            text-align: center;
        }

        .sidebar ul li a {
            color: #fff;
            text-decoration: none;
            display: block;
        }

        .sidebar ul li a:hover {
            background-color: #575757;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
            box-sizing: border-box;
            display: flex;
            justify-content: center;
            align-items: left;
            background-color: #f4f4f9;
        }

        .task-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            width: 100%;
            box-sizing: border-box;
        }

        .task-header {
            margin-bottom: 20px;
            text-align: center;
        }

        .task-header h2 {
            margin: 0;
            font-size: 28px;
            color: #333;
        }

        .task-details {
            margin-bottom: 20px;
        }

        .task-details label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #555;
        }

        .task-details p {
            margin: 0;
            padding: 10px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 5px;
            color: #333;
        }

        .back-button {
            display: block;
            text-align: center;
            margin: 20px 0;
        }

        .back-button a {
            text-decoration: none;
            background-color: #4CAF50;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
        }

        .back-button a:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="user-info">

            <span>Welcome, <?= session()->get('username') ?></span>
            <a href="<?= site_url('auth/logout') ?>" class="logout-btn">Logout</a>
        </div>
    </div>
    <div class="sidebar">
        <h2>Menu</h2>
        <ul>
        <li><a href="<?= site_url('task/taskList') ?>">Task List</a></li>
        <?php if (session()->get('role') === 'admin') : ?>
            <li><a href="<?= site_url('task/createlist') ?>">Create Task</a></li>
            <li><a href="<?= site_url('user/list') ?>">User</a></li>
        <?php endif; ?>
        </ul>
    </div>
    <div class="main-content">
        <div class="task-container">
            <div class="task-header">
                <h2>Task Details</h2>
            </div>
            <div class="task-details">
                <label for="title">Title:</label>
                <p id="title"><?= esc($task['title']) ?></p>

                <label for="description">Description:</label>
                <p id="description"><?= esc($task['description']) ?></p>

                <label for="due_date">Due Date:</label>
                <p id="due_date"><?= esc($task['due_date']) ?></p>

                <label for="priority">Priority:</label>
<p id="priority" style="color: 
<?= $task['priority'] == 'high' ? 'red' : ($task['priority'] == 'medium' ? 'orange' : 'green') ?>">
    <?= esc($task['priority']) ?>
</p>
                <label for="status">Status:</label>
                <p id="status"><?= esc($task['status']) ?></p>
            </div>
            <div class="back-button">
                <a href="<?= site_url('task/taskList') ?>">Back to Task List</a>
            </div>
        </div>
    </div>
</body>
</html>
