<?php 
    $session = session();

    // Check if the user is not logged in
    if (!$session->get('logged_in')) {
        // Redirect to the login page
        header("Location: " . base_url('login'));
    exit();
    }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Task</title>
    <link rel="stylesheet" type="text/css" href="<?= base_url('css/indexcss.css') ?>">
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .main-content {
            padding: 20px;
        }
        form {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        form label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }
        form input[type="text"],
        form textarea,
        form select,
        form input[type="date"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        form button {
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            outline: none;
            color: #fff;
            background-color: #4CAF50;
            border: none;
            border-radius: 5px;
            box-shadow: 0 5px #999;
        }
        form button:hover {
            background-color: #45a049;
        }
        form button:active {
            background-color: #45a049;
            box-shadow: 0 5px #666;
            transform: translateY(4px);
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="user-info">
            <span>Welcome, <?= session()->get('username') ?></span>
            <a href="<?= site_url('auth/logout') ?>" class="logout-btn">Logout</a>
        </div>
    </div>
    <div class="sidebar">
        <h2>Menu</h2>
        <ul>
            <li><a href="<?= site_url('task/createlist') ?>">Create Task</a></li>
            <li><a href="<?= site_url('task/taskList') ?>">Task List</a></li>
            <li><a href="<?= site_url('user/list') ?>">User</a></li>
        </ul>
    </div>
    <div class="main-content">
        <h2>Edit Task</h2>
        <form method="POST" action="<?= site_url('task/update/' . $task['s_no']) ?>">
            <label>Title:</label>
            <input type="text" name="title" value="<?= $task['title'] ?>" required>

            <label>Description:</label>
            <textarea name="description" required><?= $task['description'] ?></textarea>

            <label>Due Date:</label>
            <input type="date" name="due_date" value="<?= $task['due_date'] ?>" required>

            <label>Priority:</label>
            <select name="priority" required>
                <option value="low" <?= $task['priority'] == 'low' ? 'selected' : '' ?>>Low</option>
                <option value="medium" <?= $task['priority'] == 'medium' ? 'selected' : '' ?>>Medium</option>
                <option value="high" <?= $task['priority'] == 'high' ? 'selected' : '' ?>>High</option>
            </select>

            <label>Assign To:</label>
            <select name="assigned_to" required>
                <?php foreach ($users as $user): ?>
                    <option value="<?= $user['id'] ?>" <?= $task['assigned_to'] == $user['id'] ? 'selected' : '' ?>><?= $user['username'] ?></option>
                <?php endforeach; ?>
            </select>

            <label>Status:</label>
            <select name="status" required>
                <option value="pending" <?= $task['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
                <option value="completed" <?= $task['status'] == 'completed' ? 'selected' : '' ?>>Completed</option>
            </select>

            <button type="submit">Update Task</button>
        </form>
    </div>
</body>
</html>
