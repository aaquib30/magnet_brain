<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Auth::login');
$routes->get('/register', 'Auth::register');
$routes->get('auth/register', 'Auth::register');
$routes->post('/auth/registerSubmit', 'Auth::registerSubmit');
$routes->get('/login', 'Auth::login');
$routes->post('/auth/loginSubmit', 'Auth::loginSubmit');
$routes->get('auth/logout', 'Auth::logout');
$routes->get('/dashboard', 'Dashboard::index', ['filter' => 'auth']);
$routes->get('task', 'Task::index');
$routes->get('task/createlist', 'Task::index');
$routes->post('task/create', 'Task::create');
$routes->get('task/taskList', 'Task::taskList');
$routes->get('task/edit/(:num)', 'Task::edit/$1');
$routes->get('task/view/(:num)', 'Task::view/$1');
$routes->post('task/update/(:num)', 'Task::update/$1');
$routes->get('task/delete/(:num)', 'Task::delete/$1');
$routes->get('user/list', 'Auth::userList');
$routes->get('user/editUser/(:num)', 'Auth::editUser/$1');
$routes->post('user/editUser/(:num)', 'Auth::updateuser/$1');
$routes->get('user/deleteUser/(:num)', 'Auth::deleteUser/$1');
