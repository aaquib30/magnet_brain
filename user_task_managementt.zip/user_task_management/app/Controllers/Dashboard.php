<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Dashboard extends Controller
{
    public function index()
    {
        $session = session();
        echo "Welcome to the Dashboard, " . $session->get('username');
        echo "<br><a href='" . base_url('/auth/logout') . "'>Logout</a>";

        echo view('index');
    }
}
