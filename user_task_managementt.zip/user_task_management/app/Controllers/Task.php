<?php

namespace App\Controllers;

use App\Models\TaskModel;
use App\Models\UserModel;
use CodeIgniter\Controller;

class Task extends Controller
{
    public function index()
    {
        $taskModel = new TaskModel();


        
        // $tasks = $taskModel->findAll();
        $session = session();
        $role = $session->get('role');
        $id = $session->get('id');
        
        if($role=='user'){
            
            $tasks = $taskModel->where('assigned_to', $id)
            ->orderBy('FIELD(priority, "high", "medium", "low")')
            ->findAll();
            }else{
            $tasks = $taskModel->orderBy('FIELD(priority, "high", "medium", "low")')->findAll();

        }

        
        $userModel = new UserModel();
        $users = $userModel->findAll();
    
        $data = [
            'tasks' => $tasks,
            'role' => $role,
            'users' => $users,
        ];  
    
        return view('index', $data);
    }
    
    public function create()
    {
        helper(['form', 'url']);
        $userModel = new UserModel();
        $data['users'] = $userModel->findAll();

        if ($this->request->getMethod() == 'POST') {
            
            $session = session();

            // Debugging output
          

            // Validate the form input
            $validation = \Config\Services::validation();
            $validation->setRules([
                'title' => 'required',
                'description' => 'required',
                'due_date' => 'required|valid_date',
                'priority' => 'required',
                'assigned_to' => 'required',
            ]);

            if (!$this->validate($validation->getRules())) {
                $session->setFlashdata('errors', $validation->getErrors());
                return redirect()->to('/task/create')->withInput();
            }

            $postData = $this->request->getPost();
            $taskModel = new TaskModel();
            $taskData = [
                'title' => $postData['title'],
                'description' => $postData['description'],
                'due_date' => $postData['due_date'],
                'priority' => $postData['priority'],
                'assigned_to' => $postData['assigned_to'],
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
                'updated_by' => $session->get('username'),
                'status' => 'pending'
            ];

            // Debugging output
            

            // Save data
            if (!$taskModel->save($taskData)) {
                $session->setFlashdata('errors', $taskModel->errors());
            } else {
                $session->setFlashdata('success', 'Task created successfully');
            }

            return redirect()->to('/task/taskList');
        }

        return view('tasklist', $data);
    }

    public function taskList()
    {
        $taskModel = new TaskModel();
        $perPage = 3; // Number of tasks to display per page
        
        // Get the current page number
        $page = $this->request->getVar('page') ?? 1;
        
        // Get paginated tasks
        $tasks = $taskModel->paginate($perPage);
        
        // Generate pagination links
        $pager = $taskModel->pager;
        
        // Get session data
        $session = session();
        $role = $session->get('role');
        
        // Get all users
        $userModel = new UserModel();
        $users = $userModel->findAll();
        
        $data = [
            'tasks' => $tasks,
            'role' => $role,
            'users' => $users,
            'pager' => $pager,
        ];  
        
        return view('tasklist', $data);
    }






    public function edit($id)
    {
        $taskModel = new TaskModel();
        $userModel = new UserModel();
        $data['task'] = $taskModel->find($id);
        $data['users'] = $userModel->findAll();
        return view('edit', $data);
    }

    public function update($id)
    {
        if ($this->request->getMethod() === 'POST') {
            $taskModel = new TaskModel();
            $session = session();
            $taskData = [
                'title' => $this->request->getPost('title'),
                'description' => $this->request->getPost('description'),
                'due_date' => $this->request->getPost('due_date'),
                'priority' => $this->request->getPost('priority'),
                'assigned_to' => $this->request->getPost('assigned_to'),
                'status' => $this->request->getPost('status'),
                'updated_by' => $session->get('id')
            ];
            $taskModel->update($id, $taskData);
            return redirect()->to('/task/taskList');
        }
    }

    public function delete($id)
    {
        $taskModel = new TaskModel();
        $taskModel->delete($id);
        return redirect()->to('/task/taskList');
    }


    public function view($id)
    {
        $model = new TaskModel();
        $task = $model->find($id);

        if (!$task) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Task not found');
        }

        echo view('taskview', ['task' => $task]);
    }






}
